package com.aiol.report.gen;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.FormulaEvaluator;
import org.apache.poi.ss.usermodel.Row;

public class PdfGenerator {

	public static void main(String[] args) throws IOException {
		File[] files = new File(".").listFiles();
		for (File file : files) {
		    if (file.isFile() && file.getName().toLowerCase().endsWith(".xls") && file.getName().toLowerCase().startsWith("Sample Results_")) {
				FileInputStream fis = new FileInputStream(file);
				HSSFWorkbook wb = new HSSFWorkbook(fis);
				HSSFSheet sheet = wb.getSheetAt(0);
				FormulaEvaluator formulaEvaluator = wb.getCreationHelper().createFormulaEvaluator();
				for (Row row : sheet) {
					for (Cell cell : row) {
						switch (formulaEvaluator.evaluateInCell(cell).getCellTypeEnum()) {
						case NUMERIC:
							System.out.print(cell.getNumericCellValue() + "\t\t");
							break;
						case STRING:
							System.out.print(cell.getStringCellValue() + "\t\t");
							break;
						default:
							break;
					}
					System.out.println();
				}
		    }
		}
	}

}
